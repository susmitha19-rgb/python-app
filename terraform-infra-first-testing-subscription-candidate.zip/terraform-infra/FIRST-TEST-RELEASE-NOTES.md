# First testing-subscription release notes

## Purpose
This package is a **test-deployment candidate**, not a certified fully deployable multicloud release. It preserves all prior resource modules and adds an explicitly configured, limited-scope Azure monitoring test root at `environments/test-subscription/azure-monitoring`.

## Important limitations
- The 61 resource-module directories contain resource declarations, but code presence does not demonstrate correct Terraform/provider schemas, completeness, or security.
- Foundry AI Services is **not** a complete Foundry project. Do not treat it as one.
- Video Indexer uses an **unverified experimental AzAPI API version and payload**; do not deploy without API/schema confirmation.
- Full Azure monitoring service catalogue, AKS Managed Prometheus integration, VM Insights, hybrid discovery and cross-module testing remain unverified/incomplete.
- Existing dev/uat/prod roots contain scaffolding and are not executable end-to-end workload compositions.
- AWS and Azure module deployment plans have not been run.

## Required release gates
1. Run `scripts/validate-all-modules.sh` in an environment with Terraform CLI and provider network access; resolve **every** error.
2. Run TFLint and Checkov, review exceptions and security controls.
3. Add module-specific `terraform test` and integration tests for all required services.
4. Review provider locks and remote-state architecture; supply test account inputs.
5. Review and approve a saved plan for each intended deployment root.

Do not deploy all modules together. Start with the limited Azure monitoring test root and expand after successful validation.
