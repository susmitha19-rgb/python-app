# IaC engineering handoff

This repository is a **pre-deployment implementation baseline**, not a certified final production release. No credentials, subscription IDs, account IDs, or actual production values are embedded.

## Before deployment
1. Confirm resource naming, target cloud regions, network/private endpoint topology, SKU and quotas.
2. Pin and test compatible Terraform/provider versions; run `terraform fmt -check -recursive`, `terraform init -backend=false`, `terraform validate`, TFLint and Checkov for each module and root.
3. Implement remaining modules listed as NOT_IMPLEMENTED in IMPLEMENTATION-STATUS-FINAL.csv.
4. Resolve provider schema drift in resource code; code was generated without Terraform CLI/provider downloads.
5. Configure remote backend and workload identity federation in each environment; never commit credentials or actual secrets.
6. Integrate resource dependencies through root and parent modules, with outputs as inputs.
7. Validate monitoring baseline coverage for all required service types, AKS managed Prometheus, VM Insights and subscription scope.
8. Run plans and ephemeral cloud integration tests in dev, then peer review and promote to UAT and production.

## Monitoring baseline
Previous phases contain Log Analytics, action groups, metric/activity/log alerts, DCR, AMA and monitoring parent module candidates. Confirm alert signal availability and action-group escalation mapping in the target subscription. Sev 0–4 labels are business policy; Azure Monitor metric-alert severity supports numeric 0–4.

## Security
Required secret variables are sensitive in Terraform, but state may still contain secrets; use secure remote state and secret injection.
