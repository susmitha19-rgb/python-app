# Monitoring example
Copy `terraform.tfvars.example` to a locally ignored `.tfvars` file and replace placeholders. Create the resource group first. `terraform init`, `terraform validate`, then inspect `terraform plan` before any apply. This example does not provision the resource group.
