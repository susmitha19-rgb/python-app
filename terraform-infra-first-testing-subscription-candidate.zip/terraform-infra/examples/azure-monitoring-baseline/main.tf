module "monitoring" {
  source                  = "../../cloud-infra/monitoring/azure-monitoring-baseline"
  workspace_name          = "law-example-monitoring"
  resource_group_name     = var.resource_group_name
  location                = var.location
  action_group_name       = "ag-example-monitoring"
  action_group_short_name = "monbase"
  email_receivers         = { operations = var.notification_email }
  tags                    = { environment = "example", managed_by = "terraform" }
  # Add approved metric_alerts and diagnostic_targets from the inventory.
}
