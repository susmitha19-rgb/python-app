# Phase 3 integration
Set the following optional inputs on the `azure-monitoring-baseline` parent module:

```hcl
enable_windows_performance_dcr = true
windows_performance_dcr_name   = "dcr-win-prod"
enable_prometheus_workspace    = true
prometheus_workspace_name     = "amw-prod"
activity_log_alerts = {
  "subscription-service-health" = {
    scopes   = ["/subscriptions/00000000-0000-0000-0000-000000000000"]
    category = "ServiceHealth"
    notify   = true
  }
}
```

Supply `vm_ama_targets` only after the VM has a managed identity and a compatible DCR exists. The generated Windows DCR ID is an output; use a second apply or explicitly compose a VM onboarding root module when consuming it as an input.
