Policy design pending. Do not claim compliance enforcement until actual rules and tests exist.
