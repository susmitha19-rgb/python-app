# Phase 4 release notes

Built on Phase 3. Adds eight real resource-level implementation candidates and one opt-in Azure VM CPU monitoring alert catalogue. All remaining scaffold modules are **not implemented**. The ZIP is not a final production release.

Read `docs/architecture/PHASE4-SCOPE-AND-GAPS.md` before deployment.
