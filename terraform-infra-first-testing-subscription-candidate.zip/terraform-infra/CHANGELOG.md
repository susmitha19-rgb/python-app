# Changelog

## 0.1.0
- Initial repository structure and Azure monitoring starter modules.

## Phase 2 (2026-11-21)
- Added monitoring implementations and opt-in composition with example root.
- Documented outstanding enterprise monitoring integrations and validation gates.
