output "workspace_id" { value = module.workspace.id }
output "action_group_id" { value = module.action_group.id }
output "application_insights_id" { value = var.enable_application_insights ? module.application_insights[0].id : null }
output "metric_alert_ids" { value = { for k, m in module.metric_alerts : k => m.id } }

output "windows_performance_dcr_id" { value = var.enable_windows_performance_dcr ? module.windows_performance_dcr[0].id : null }
output "vm_ama_extension_ids" { value = { for k, m in module.vm_ama : k => m.extension_id } }
output "activity_log_alert_ids" { value = { for k, m in module.activity_log_alerts : k => m.id } }
output "prometheus_workspace_id" { value = var.enable_prometheus_workspace ? module.prometheus_workspace[0].id : null }
