variable "workspace_name" { type = string }
variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "retention_in_days" { type = number; default = 30 }
variable "action_group_name" { type = string }
variable "action_group_short_name" { type = string }
variable "email_receivers" { type = map(string); default = {} }
variable "enable_application_insights" { type = bool; default = false }
variable "application_insights_name" { type = string; default = "unused-appinsights" }
variable "tags" { type = map(string); default = {} }
variable "metric_alerts" {
  type = map(object({
    scopes = list(string)
    description = optional(string, "Managed by Terraform")
    severity = number
    metric_namespace = string
    metric_name = string
    aggregation = optional(string, "Average")
    operator = optional(string, "GreaterThan")
    threshold = number
    frequency = optional(string, "PT5M")
    window_size = optional(string, "PT15M")
  }))
  default = {}
}
variable "diagnostic_targets" {
  type = map(object({
    resource_id = string
    log_categories = optional(set(string), [])
    log_category_groups = optional(set(string), [])
    metric_categories = optional(set(string), [])
  }))
  default = {}
}

variable "enable_windows_performance_dcr" { type = bool; default = false }
variable "windows_performance_dcr_name" { type = string; default = "dcr-windows-performance" }
variable "vm_ama_targets" {
  description = "Explicit inventory of VM targets; DCR must be OS-compatible and VMs must have managed identities."
  type = map(object({ virtual_machine_id = string, os_type = string, data_collection_rule_id = string }))
  default = {}
}
variable "activity_log_alerts" {
  type = map(object({
    scopes         = list(string)
    description    = optional(string, "Subscription activity")
    category       = optional(string, "Administrative")
    operation_name = optional(string)
    status         = optional(string)
    notify         = optional(bool, true)
  }))
  default = {}
}
variable "enable_prometheus_workspace" { type = bool; default = false }
variable "prometheus_workspace_name" { type = string; default = "amw-monitoring" }

variable "vm_cpu_resource_ids" {
  description = "Explicit VM inventory for optional Sev 1 CPU alerts. Empty by default."
  type = map(string)
  default = {}
}
