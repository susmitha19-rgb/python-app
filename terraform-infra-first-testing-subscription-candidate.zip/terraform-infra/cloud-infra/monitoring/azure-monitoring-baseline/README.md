# Azure monitoring baseline (composition)
Creates a workspace and common action group; optionally Application Insights, metric alerts, and diagnostic settings for **explicitly supplied** resources. Resource discovery is hybrid: static inventory via `metric_alerts` / `diagnostic_targets`, and externally curated discovery outputs can feed the same variables. No automatic subscription discovery is claimed.

Severity 0–4 is Azure Monitor's severity scale. Severity 4 receives no action group by design. Severity 0/1 SMS, incident integration, AMA, VM Insights and AKS Managed Prometheus require separate implementations/configuration and are NOT automatically enabled here. Email-only is configured in this phase. Avoid committing real addresses/secrets.

The workspace has `prevent_destroy = true`; plan intentional migrations carefully. Requires an existing resource group and an authenticated AzureRM provider in the root.
