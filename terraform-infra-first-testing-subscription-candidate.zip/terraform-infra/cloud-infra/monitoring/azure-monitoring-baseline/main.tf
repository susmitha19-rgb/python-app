module "workspace" {
  source              = "../../../modules/azure/monitoring/log-analytics"
  name                = var.workspace_name
  location            = var.location
  resource_group_name = var.resource_group_name
  retention_in_days   = var.retention_in_days
  tags                = var.tags
}
module "action_group" {
  source              = "../../../modules/azure/monitoring/action-group"
  name                = var.action_group_name
  short_name          = var.action_group_short_name
  resource_group_name = var.resource_group_name
  email_receivers     = var.email_receivers
  tags                = var.tags
}
module "application_insights" {
  count               = var.enable_application_insights ? 1 : 0
  source              = "../../../modules/azure/monitoring/application-insights"
  name                = var.application_insights_name
  location            = var.location
  resource_group_name = var.resource_group_name
  workspace_id        = module.workspace.id
  tags                = var.tags
}
module "metric_alerts" {
  for_each            = var.metric_alerts
  source              = "../../../modules/azure/monitoring/metric-alert"
  name                = each.key
  resource_group_name = var.resource_group_name
  scopes              = each.value.scopes
  description         = each.value.description
  severity            = each.value.severity
  metric_namespace    = each.value.metric_namespace
  metric_name         = each.value.metric_name
  aggregation         = each.value.aggregation
  operator            = each.value.operator
  threshold           = each.value.threshold
  frequency           = each.value.frequency
  window_size         = each.value.window_size
  action_group_ids    = each.value.severity == 4 ? [] : [module.action_group.id]
  tags                = var.tags
}
module "diagnostics" {
  for_each            = var.diagnostic_targets
  source              = "../../../modules/azure/monitoring/diagnostic-settings"
  name                = each.key
  target_resource_id  = each.value.resource_id
  workspace_id        = module.workspace.id
  log_categories      = each.value.log_categories
  log_category_groups = each.value.log_category_groups
  metric_categories   = each.value.metric_categories
}

# Phase 3: opt-in monitoring integrations. Existing defaults are unchanged.
module "windows_performance_dcr" {
  count                 = var.enable_windows_performance_dcr ? 1 : 0
  source                = "../../../modules/azure/monitoring/data-collection-rule"
  name                  = var.windows_performance_dcr_name
  location              = var.location
  resource_group_name   = var.resource_group_name
  workspace_resource_id = module.workspace.id
  tags                  = var.tags
}
module "vm_ama" {
  for_each                = var.vm_ama_targets
  source                  = "../../../modules/azure/monitoring/vm-insights"
  virtual_machine_id      = each.value.virtual_machine_id
  os_type                 = each.value.os_type
  data_collection_rule_id = each.value.data_collection_rule_id
  association_name        = "ama-${each.key}"
  tags                    = var.tags
}
module "activity_log_alerts" {
  for_each            = var.activity_log_alerts
  source              = "../../../modules/azure/monitoring/activity-log-alert"
  name                = each.key
  resource_group_name = var.resource_group_name
  scopes              = each.value.scopes
  description         = each.value.description
  category            = each.value.category
  operation_name      = each.value.operation_name
  status              = each.value.status
  action_group_ids    = each.value.notify ? [module.action_group.id] : []
  tags                = var.tags
}
module "prometheus_workspace" {
  count               = var.enable_prometheus_workspace ? 1 : 0
  source              = "../../../modules/azure/monitoring/managed-prometheus"
  name                = var.prometheus_workspace_name
  resource_group_name = var.resource_group_name
  location            = var.location
  tags                = var.tags
}
