# Opt-in baseline for Azure VMs. All resource IDs are explicitly provided; no guessed inventory.
# Verify metric support in the target Azure region and resource SKU before enabling.
locals {
  vm_cpu_alerts = {
    for key, id in var.vm_cpu_resource_ids : "vm-${key}-cpu-high" => {
      scopes = [id]
      description = "VM CPU > 90% averaged over 15 minutes"
      severity = 1
      metric_namespace = "Microsoft.Compute/virtualMachines"
      metric_name = "Percentage CPU"
      aggregation = "Average"
      operator = "GreaterThan"
      threshold = 90
      frequency = "PT5M"
      window_size = "PT15M"
    }
  }
}
module "vm_cpu_catalogue" {
  for_each = local.vm_cpu_alerts
  source = "../../../modules/azure/monitoring/metric-alert"
  name = each.key
  resource_group_name = var.resource_group_name
  scopes = each.value.scopes
  description = each.value.description
  severity = each.value.severity
  metric_namespace = each.value.metric_namespace
  metric_name = each.value.metric_name
  aggregation = each.value.aggregation
  operator = each.value.operator
  threshold = each.value.threshold
  frequency = each.value.frequency
  window_size = each.value.window_size
  action_group_ids = [module.action_group.id]
  tags = var.tags
}
