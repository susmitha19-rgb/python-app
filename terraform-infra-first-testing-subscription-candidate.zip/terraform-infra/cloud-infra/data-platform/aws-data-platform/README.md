# aws-data-platform

**Composition scaffold only.** Configure tested child modules, inputs and outputs before deployment.
