# azure-foundation

**Composition scaffold only.** Configure tested child modules, inputs and outputs before deployment.
