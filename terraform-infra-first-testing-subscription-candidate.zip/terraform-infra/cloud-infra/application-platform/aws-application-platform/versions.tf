terraform { required_version = ">= 1.6.0, < 2.0.0" }
