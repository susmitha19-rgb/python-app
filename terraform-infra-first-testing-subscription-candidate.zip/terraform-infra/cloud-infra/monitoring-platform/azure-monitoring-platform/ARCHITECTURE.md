# Subscription-wide Azure Monitoring architecture

- Hybrid discovery: explicit critical-resource scope IDs plus approved discovery data sources/inventory generated outside Terraform; do not automatically alert on every resource without verifying metric namespaces.
- Common action group: shared email notification; SMS escalation requires explicit receiver configuration and organizational approval.
- Sev 0 critical (24x7 SMS/email), Sev 1 high (5–15m SMS/email), Sev 2 medium (1–2h email/ticket), Sev 3 low (business-hours email/ticket), Sev 4 informational (dashboard only). Alert severity does not itself enforce notification routing.
- AMA + DCR/DCRA and VM Insights require VM extension/association implementation; Managed Prometheus for AKS requires Azure Monitor workspace and AKS integration. These are planned, not implemented in this starter.
- Services: App Service, Plan, App Gateway, App Insights, Redis, LAW, Firewall, Key Vault, AKS, Load Balancer, NAT, RSV, SQL DB/Server, VM, VMSS, Storage.
- Production metrics must be validated per resource type, metric namespace, dimensions and region. No blanket assumptions about supported metrics.
