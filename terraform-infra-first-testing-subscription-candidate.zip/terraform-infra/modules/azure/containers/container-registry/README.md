# container-registry

Resource implementation mirrored from `modules/azure/paas/container-registry` to maintain compatibility with the existing repository taxonomy. Prefer a single canonical module in new integrations. Provider schema and deployment validation remain required.
