# key-vault

Resource-level module for `azurerm_key_vault`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
