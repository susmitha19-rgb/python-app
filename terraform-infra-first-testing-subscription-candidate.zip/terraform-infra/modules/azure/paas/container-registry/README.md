# container-registry

Resource-level module for `azurerm_container_registry`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
