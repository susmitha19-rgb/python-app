# API version and resource properties must be verified against the target Azure subscription.
resource "azapi_resource" "this" {
  type      = "Microsoft.VideoIndexer/accounts@2024-01-01"
  name      = var.name
  location  = var.location
  parent_id = var.resource_group_id
  body = {
    properties = {
      storageServices = { resourceId = var.storage_account_id }
    }
    sku = { name = var.sku_name }
  }
  tags = var.tags
}
