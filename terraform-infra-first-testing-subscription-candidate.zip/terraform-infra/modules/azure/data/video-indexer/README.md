# Azure AI Video Indexer

**Experimental candidate:** AzAPI account resource. Verify resource API version, SKU, storage binding, account prerequisites and schema with the Azure provider before use. Do not deploy without verification.
