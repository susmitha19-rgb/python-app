variable "name" { type = string }
variable "location" { type = string }
variable "resource_group_id" { type = string }
variable "storage_account_id" { type = string }
variable "sku_name" { type = string default = "S1" }
variable "tags" { type = map(string) default = {} }
