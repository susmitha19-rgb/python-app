variable "name" {
  description = "Input name for azurerm_redis_cache."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_redis_cache."
  type = string
}

variable "location" {
  description = "Input location for azurerm_redis_cache."
  type = string
}

variable "capacity" {
  description = "Input capacity for azurerm_redis_cache."
  type = number
}

variable "family" {
  description = "Input family for azurerm_redis_cache."
  type = string
}

variable "sku_name" {
  description = "Input sku_name for azurerm_redis_cache."
  type = string
}

variable "non_ssl_port_enabled" {
  description = "Input non_ssl_port_enabled for azurerm_redis_cache."
  type = bool
  default = false
}

variable "minimum_tls_version" {
  description = "Input minimum_tls_version for azurerm_redis_cache."
  type = string
  default = "1.2"
}

variable "tags" {
  type = map(string)
  default = {}
}
