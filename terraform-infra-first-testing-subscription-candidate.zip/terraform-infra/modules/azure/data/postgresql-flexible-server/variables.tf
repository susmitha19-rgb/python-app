variable "name" {
  description = "Input name for azurerm_postgresql_flexible_server."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_postgresql_flexible_server."
  type = string
}

variable "location" {
  description = "Input location for azurerm_postgresql_flexible_server."
  type = string
}

variable "administrator_login" {
  description = "Input administrator_login for azurerm_postgresql_flexible_server."
  type = string
}

variable "administrator_password" {
  description = "Input administrator_password for azurerm_postgresql_flexible_server."
  type = string
  sensitive = true
}

variable "sku_name" {
  description = "Input sku_name for azurerm_postgresql_flexible_server."
  type = string
}

variable "storage_mb" {
  description = "Input storage_mb for azurerm_postgresql_flexible_server."
  type = number
}

variable "version" {
  description = "Input version for azurerm_postgresql_flexible_server."
  type = string
}

variable "backup_retention_days" {
  description = "Input backup_retention_days for azurerm_postgresql_flexible_server."
  type = number
  default = 7
}

variable "public_network_access_enabled" {
  description = "Input public_network_access_enabled for azurerm_postgresql_flexible_server."
  type = bool
  default = false
}

variable "tags" {
  type = map(string)
  default = {}
}
