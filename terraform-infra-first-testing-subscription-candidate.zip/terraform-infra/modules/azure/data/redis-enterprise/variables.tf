variable "name" {
  description = "Input name for azurerm_redis_enterprise_cluster."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_redis_enterprise_cluster."
  type = string
}

variable "location" {
  description = "Input location for azurerm_redis_enterprise_cluster."
  type = string
}

variable "sku_name" {
  description = "Input sku_name for azurerm_redis_enterprise_cluster."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
