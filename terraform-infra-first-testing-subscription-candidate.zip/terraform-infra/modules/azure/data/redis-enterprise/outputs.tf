output "id" { value = azurerm_redis_enterprise_cluster.this.id }
output "hostname" { value = azurerm_redis_enterprise_cluster.this.hostname }
