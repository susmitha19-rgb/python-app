variable "name" {
  description = "Input name for azurerm_search_service."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_search_service."
  type = string
}

variable "location" {
  description = "Input location for azurerm_search_service."
  type = string
}

variable "sku" {
  description = "Input sku for azurerm_search_service."
  type = string
}

variable "replica_count" {
  description = "Input replica_count for azurerm_search_service."
  type = number
  default = 1
}

variable "partition_count" {
  description = "Input partition_count for azurerm_search_service."
  type = number
  default = 1
}

variable "tags" {
  type = map(string)
  default = {}
}
