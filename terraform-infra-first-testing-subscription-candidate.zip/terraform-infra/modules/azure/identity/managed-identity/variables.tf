variable "name" {
  description = "Input name for azurerm_user_assigned_identity."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_user_assigned_identity."
  type = string
}

variable "location" {
  description = "Input location for azurerm_user_assigned_identity."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
