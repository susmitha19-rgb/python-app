# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_user_assigned_identity" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  location = var.location
  tags = var.tags
}
