variable "scope" {
  description = "Input scope for azurerm_role_assignment."
  type = string
}

variable "role_definition_name" {
  description = "Input role_definition_name for azurerm_role_assignment."
  type = string
}

variable "principal_id" {
  description = "Input principal_id for azurerm_role_assignment."
  type = string
}
