variable "name" {
  description = "Input name for azurerm_subnet."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_subnet."
  type = string
}

variable "virtual_network_name" {
  description = "Input virtual_network_name for azurerm_subnet."
  type = string
}

variable "address_prefixes" {
  description = "Input address_prefixes for azurerm_subnet."
  type = list(string)
}
