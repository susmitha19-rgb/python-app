variable "name" {
  description = "Input name for azurerm_virtual_network."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_virtual_network."
  type = string
}

variable "location" {
  description = "Input location for azurerm_virtual_network."
  type = string
}

variable "address_space" {
  description = "Input address_space for azurerm_virtual_network."
  type = list(string)
}

variable "tags" {
  type = map(string)
  default = {}
}
