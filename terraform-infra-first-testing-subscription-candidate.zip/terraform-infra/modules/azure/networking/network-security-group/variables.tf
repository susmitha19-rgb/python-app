variable "name" {
  description = "Input name for azurerm_network_security_group."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_network_security_group."
  type = string
}

variable "location" {
  description = "Input location for azurerm_network_security_group."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
