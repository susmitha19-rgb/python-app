variable "name" {
  description = "Input name for azurerm_private_endpoint."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_private_endpoint."
  type = string
}

variable "location" {
  description = "Input location for azurerm_private_endpoint."
  type = string
}

variable "subnet_id" {
  description = "Input subnet_id for azurerm_private_endpoint."
  type = string
}

variable "private_connection_resource_id" {
  description = "Input private_connection_resource_id for azurerm_private_endpoint."
  type = string
}

variable "subresource_names" {
  description = "Input subresource_names for azurerm_private_endpoint."
  type = list(string)
}
