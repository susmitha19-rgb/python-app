# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_private_dns_zone" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
}
