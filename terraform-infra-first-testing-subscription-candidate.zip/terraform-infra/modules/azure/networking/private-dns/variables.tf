variable "name" {
  description = "Input name for azurerm_private_dns_zone."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_private_dns_zone."
  type = string
}
