# app-service-plan

Resource-level module for `azurerm_service_plan`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
