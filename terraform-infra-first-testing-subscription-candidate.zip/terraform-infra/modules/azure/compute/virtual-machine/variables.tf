variable "name" {
  description = "Input name for azurerm_linux_virtual_machine."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_linux_virtual_machine."
  type = string
}

variable "location" {
  description = "Input location for azurerm_linux_virtual_machine."
  type = string
}

variable "size" {
  description = "Input size for azurerm_linux_virtual_machine."
  type = string
}

variable "admin_username" {
  description = "Input admin_username for azurerm_linux_virtual_machine."
  type = string
}

variable "network_interface_ids" {
  description = "Input network_interface_ids for azurerm_linux_virtual_machine."
  type = list(string)
}

variable "ssh_public_key" {
  description = "Input ssh_public_key for azurerm_linux_virtual_machine."
  type = string
}

variable "disable_password_authentication" {
  description = "Input disable_password_authentication for azurerm_linux_virtual_machine."
  type = bool
  default = true
  sensitive = true
}

variable "tags" {
  type = map(string)
  default = {}
}
