# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_linux_virtual_machine" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  location = var.location
  size = var.size
  admin_username = var.admin_username
  network_interface_ids = var.network_interface_ids
  disable_password_authentication = var.disable_password_authentication
  tags = var.tags
  os_disk { caching = "ReadWrite"
   storage_account_type = "Premium_LRS" }
   source_image_reference { publisher = "Canonical"
   offer = "ubuntu-24_04-lts"
   sku = "server"
   version = "latest" }
   admin_ssh_key { username = var.admin_username
   public_key = var.ssh_public_key }
}
