variable "name" {
  description = "Input name for azurerm_linux_function_app."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_linux_function_app."
  type = string
}

variable "location" {
  description = "Input location for azurerm_linux_function_app."
  type = string
}

variable "service_plan_id" {
  description = "Input service_plan_id for azurerm_linux_function_app."
  type = string
}

variable "storage_account_name" {
  description = "Input storage_account_name for azurerm_linux_function_app."
  type = string
}

variable "storage_account_access_key" {
  description = "Input storage_account_access_key for azurerm_linux_function_app."
  type = string
  sensitive = true
}

variable "https_only" {
  description = "Input https_only for azurerm_linux_function_app."
  type = bool
  default = true
}

variable "tags" {
  type = map(string)
  default = {}
}
