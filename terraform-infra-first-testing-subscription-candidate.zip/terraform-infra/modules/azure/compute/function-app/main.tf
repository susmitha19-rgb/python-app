# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_linux_function_app" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  location = var.location
  service_plan_id = var.service_plan_id
  storage_account_name = var.storage_account_name
  storage_account_access_key = var.storage_account_access_key
  https_only = var.https_only
  tags = var.tags
  site_config { application_stack { node_version = "22" } }
}
