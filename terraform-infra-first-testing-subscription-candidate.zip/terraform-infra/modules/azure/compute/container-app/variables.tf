variable "name" {
  description = "Input name for azurerm_container_app."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_container_app."
  type = string
}

variable "container_app_environment_id" {
  description = "Input container_app_environment_id for azurerm_container_app."
  type = string
}

variable "revision_mode" {
  description = "Input revision_mode for azurerm_container_app."
  type = string
}

variable "image" {
  description = "Input image for azurerm_container_app."
  type = string
}

variable "cpu" {
  description = "Input cpu for azurerm_container_app."
  type = number
}

variable "memory" {
  description = "Input memory for azurerm_container_app."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
