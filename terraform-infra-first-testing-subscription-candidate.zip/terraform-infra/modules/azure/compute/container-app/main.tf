# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_container_app" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  container_app_environment_id = var.container_app_environment_id
  revision_mode = var.revision_mode
  tags = var.tags
  template { container { name = var.name
   image = var.image
   cpu = var.cpu
   memory = var.memory }
   min_replicas = 1
   max_replicas = 2 }
}
