# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_linux_web_app" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  location = var.location
  service_plan_id = var.service_plan_id
  https_only = var.https_only
  tags = var.tags
  site_config {}
}
