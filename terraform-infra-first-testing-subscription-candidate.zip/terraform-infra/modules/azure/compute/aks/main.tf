# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_kubernetes_cluster" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  location = var.location
  dns_prefix = var.dns_prefix
  tags = var.tags
  default_node_pool { name = "system"
   node_count = var.node_count
   vm_size = var.vm_size }
   identity { type = "SystemAssigned" }
}
