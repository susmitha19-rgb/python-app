variable "name" {
  description = "Input name for azurerm_kubernetes_cluster."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_kubernetes_cluster."
  type = string
}

variable "location" {
  description = "Input location for azurerm_kubernetes_cluster."
  type = string
}

variable "dns_prefix" {
  description = "Input dns_prefix for azurerm_kubernetes_cluster."
  type = string
}

variable "node_count" {
  description = "Input node_count for azurerm_kubernetes_cluster."
  type = number
}

variable "vm_size" {
  description = "Input vm_size for azurerm_kubernetes_cluster."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
