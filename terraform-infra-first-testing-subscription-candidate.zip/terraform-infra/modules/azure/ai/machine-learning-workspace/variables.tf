variable "name" {
  description = "Input name for azurerm_machine_learning_workspace."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_machine_learning_workspace."
  type = string
}

variable "location" {
  description = "Input location for azurerm_machine_learning_workspace."
  type = string
}

variable "application_insights_id" {
  description = "Input application_insights_id for azurerm_machine_learning_workspace."
  type = string
}

variable "key_vault_id" {
  description = "Input key_vault_id for azurerm_machine_learning_workspace."
  type = string
}

variable "storage_account_id" {
  description = "Input storage_account_id for azurerm_machine_learning_workspace."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
