# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_machine_learning_workspace" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  location = var.location
  application_insights_id = var.application_insights_id
  key_vault_id = var.key_vault_id
  storage_account_id = var.storage_account_id
  tags = var.tags
  identity { type = "SystemAssigned" }
}
