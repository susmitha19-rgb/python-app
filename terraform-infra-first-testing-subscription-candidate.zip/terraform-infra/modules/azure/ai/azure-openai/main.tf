# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "azurerm_cognitive_account" "this" {
  name = var.name
  resource_group_name = var.resource_group_name
  location = var.location
  sku_name = var.sku_name
  tags = var.tags
  kind = "OpenAI"
   custom_subdomain_name = var.name
}
