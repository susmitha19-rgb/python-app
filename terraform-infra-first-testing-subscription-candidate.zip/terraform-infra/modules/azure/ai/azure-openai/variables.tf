variable "name" {
  description = "Input name for azurerm_cognitive_account."
  type = string
}

variable "resource_group_name" {
  description = "Input resource_group_name for azurerm_cognitive_account."
  type = string
}

variable "location" {
  description = "Input location for azurerm_cognitive_account."
  type = string
}

variable "sku_name" {
  description = "Input sku_name for azurerm_cognitive_account."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
