variable "name" { type = string }
variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "sku_name" { type = string default = "S0" }
variable "custom_subdomain_name" { type = string }
variable "public_network_access_enabled" { type = bool default = false }
variable "tags" { type = map(string) default = {} }
