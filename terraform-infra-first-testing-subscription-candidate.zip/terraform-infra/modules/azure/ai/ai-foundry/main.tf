# Azure AI Services account used by Foundry workloads. Foundry projects/hubs require separate configuration.
resource "azurerm_ai_services" "this" {
  name                  = var.name
  location              = var.location
  resource_group_name   = var.resource_group_name
  sku_name              = var.sku_name
  custom_subdomain_name = var.custom_subdomain_name
  public_network_access = var.public_network_access_enabled ? "Enabled" : "Disabled"
  local_authentication_enabled = false
  tags                  = var.tags
  identity { type = "SystemAssigned" }
}
