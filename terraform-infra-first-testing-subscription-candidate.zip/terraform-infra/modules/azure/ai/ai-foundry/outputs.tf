output "id" { value = azurerm_ai_services.this.id }
output "principal_id" { value = azurerm_ai_services.this.identity[0].principal_id }
