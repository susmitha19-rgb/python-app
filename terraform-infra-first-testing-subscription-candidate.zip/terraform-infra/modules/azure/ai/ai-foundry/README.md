# Azure AI Services for Microsoft Foundry

Creates an Azure AI Services account, **not** a complete Microsoft Foundry hub/project. Configure projects, model deployments, RBAC and private connectivity separately. Validate AzureRM 4.x schema before use.
