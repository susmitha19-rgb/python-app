# storage-account

Resource-level module for `azurerm_storage_account`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
