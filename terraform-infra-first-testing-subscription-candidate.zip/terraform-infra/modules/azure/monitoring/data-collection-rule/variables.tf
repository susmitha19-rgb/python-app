variable "name" { type = string }
variable "location" { type = string }
variable "resource_group_name" { type = string }
variable "workspace_resource_id" { type = string }
variable "description" { type = string; default = "Windows VM performance telemetry" }
variable "sampling_frequency_in_seconds" { type = number; default = 60
  validation { condition = var.sampling_frequency_in_seconds >= 10 && var.sampling_frequency_in_seconds <= 300; error_message = "Sampling frequency must be between 10 and 300 seconds." }
}
variable "counter_specifiers" { type = list(string); default = ["\\Processor(_Total)\\% Processor Time", "\\Memory\\Available MBytes"] }
variable "tags" { type = map(string); default = {} }
