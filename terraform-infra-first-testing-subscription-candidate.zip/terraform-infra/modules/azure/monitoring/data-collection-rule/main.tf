resource "azurerm_monitor_data_collection_rule" "this" {
  name                = var.name
  location            = var.location
  resource_group_name = var.resource_group_name
  description         = var.description
  kind                = "Windows"
  destinations {
    log_analytics {
      workspace_resource_id = var.workspace_resource_id
      name                  = "central-law"
    }
  }
  data_sources {
    performance_counter {
      name                          = "vm-performance"
      streams                       = ["Microsoft-Perf"]
      sampling_frequency_in_seconds = var.sampling_frequency_in_seconds
      counter_specifiers            = var.counter_specifiers
    }
  }
  data_flow {
    streams      = ["Microsoft-Perf"]
    destinations = ["central-law"]
  }
  tags = var.tags
}
