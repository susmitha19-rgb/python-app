output "id" { value = azurerm_monitor_data_collection_rule.this.id }
output "name" { value = azurerm_monitor_data_collection_rule.this.name }
