# Data Collection Rule (Windows VM performance)
Creates a Windows performance-counter DCR that sends `Microsoft-Perf` to a Log Analytics workspace. Does **not** implement full VM Insights dependency-map collection or Linux syslog. Use a separate Linux-compatible DCR for Linux workloads. Requires an AMA extension and association on each VM.
