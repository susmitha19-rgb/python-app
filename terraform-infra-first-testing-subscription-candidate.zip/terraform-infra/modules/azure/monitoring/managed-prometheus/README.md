# Azure Monitor workspace for Managed Prometheus
Creates the Azure Monitor workspace used to store Prometheus metrics. **This does not enable the AKS Azure Monitor metrics addon or configure the AKS cluster's metrics profile.** Configure the AKS metrics addon in the AKS cluster module, with this workspace ID. Validate the AKS provider schema and addon permissions before deployment.
