variable "name" { type = string }
variable "resource_group_name" { type = string }
variable "scopes" { type = list(string)
  validation { condition = length(var.scopes) > 0; error_message = "At least one scope is required." }
}
variable "description" { type = string; default = "Azure activity log alert" }
variable "enabled" { type = bool; default = true }
variable "category" { type = string; default = "Administrative" }
variable "operation_name" { type = string; default = null }
variable "status" { type = string; default = null }
variable "action_group_ids" { type = list(string); default = [] }
variable "tags" { type = map(string); default = {} }
