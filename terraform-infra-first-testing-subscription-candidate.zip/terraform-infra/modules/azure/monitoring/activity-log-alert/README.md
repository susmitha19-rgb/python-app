# Subscription activity log alert
Use a subscription resource ID in `scopes` for subscription-wide coverage. Category, operation and status filters are optional. This Azure resource has no numeric severity field; severity must be represented in your alert catalogue and incident routing.
