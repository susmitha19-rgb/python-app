resource "azurerm_monitor_activity_log_alert" "this" {
  name                = var.name
  resource_group_name = var.resource_group_name
  scopes              = var.scopes
  description         = var.description
  enabled             = var.enabled
  criteria {
    category       = var.category
    operation_name = var.operation_name
    status         = var.status
  }
  dynamic "action" {
    for_each = toset(var.action_group_ids)
    content { action_group_id = action.value }
  }
  tags = var.tags
}
