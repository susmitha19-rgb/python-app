variable "name" { type = string }
variable "resource_group_name" { type = string }
variable "scopes" { type = list(string) }
variable "description" { type = string; default = "Managed by Terraform" }
variable "severity" { type = number
  validation { condition = contains([0,1,2,3,4],var.severity); error_message = "Severity must be 0 through 4." }
}
variable "enabled" { type = bool; default = true }
variable "frequency" { type = string; default = "PT5M" }
variable "window_size" { type = string; default = "PT15M" }
variable "metric_namespace" { type = string; default = null }
variable "metric_name" { type = string }
variable "aggregation" { type = string; default = "Average" }
variable "operator" { type = string; default = "GreaterThan" }
variable "threshold" { type = number }
variable "action_group_ids" { type = list(string); default = [] }
variable "tags" { type = map(string); default = {} }
