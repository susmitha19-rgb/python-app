# DCR association
Associates an existing Data Collection Rule to a supported Azure resource. Caller must provide a valid target resource ID.
