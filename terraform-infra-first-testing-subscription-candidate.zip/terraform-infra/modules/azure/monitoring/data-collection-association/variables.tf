variable "name" { type = string }
variable "target_resource_id" { type = string }
variable "data_collection_rule_id" { type = string }
variable "description" { type = string; default = "Terraform-managed DCR association" }
