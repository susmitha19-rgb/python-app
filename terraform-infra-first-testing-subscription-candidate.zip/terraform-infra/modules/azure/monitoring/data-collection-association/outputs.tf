output "id" { value = azurerm_monitor_data_collection_rule_association.this.id }
