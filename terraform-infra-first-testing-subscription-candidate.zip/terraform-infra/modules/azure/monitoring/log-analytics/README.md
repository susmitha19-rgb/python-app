# log-analytics

**Status: IMPLEMENTED — requires terraform validation and Azure integration testing.**

Provider is configured by the calling root module. Review production controls before applying.
