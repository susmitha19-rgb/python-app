resource "azurerm_virtual_machine_extension" "ama" {
  name                       = var.extension_name
  virtual_machine_id         = var.virtual_machine_id
  publisher                  = "Microsoft.Azure.Monitor"
  type                       = var.os_type == "Windows" ? "AzureMonitorWindowsAgent" : "AzureMonitorLinuxAgent"
  type_handler_version       = "1.0"
  auto_upgrade_minor_version = true
  automatic_upgrade_enabled  = true
  settings                   = jsonencode({ authentication = { managedIdentity = {} } })
  tags                       = var.tags
}
resource "azurerm_monitor_data_collection_rule_association" "this" {
  name                    = var.association_name
  target_resource_id      = var.virtual_machine_id
  data_collection_rule_id = var.data_collection_rule_id
  depends_on              = [azurerm_virtual_machine_extension.ama]
}
