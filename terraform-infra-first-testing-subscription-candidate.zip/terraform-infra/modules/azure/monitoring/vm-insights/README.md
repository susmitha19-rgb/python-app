# Azure Monitor Agent VM onboarding
Installs AMA and associates a DCR. **Prerequisites:** the VM has a managed identity, and the supplied DCR is compatible with the VM operating system. This is AMA performance telemetry onboarding, **not full VM Insights** (which also requires the appropriate VM Insights DCR streams and dependencies).
