variable "virtual_machine_id" { type = string }
variable "data_collection_rule_id" { type = string }
variable "os_type" { type = string
  validation { condition = contains(["Windows", "Linux"], var.os_type); error_message = "os_type must be Windows or Linux." }
}
variable "extension_name" { type = string; default = "AzureMonitorAgent" }
variable "association_name" { type = string; default = "ama-dcr" }
variable "tags" { type = map(string); default = {} }
