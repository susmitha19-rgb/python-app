output "extension_id" { value = azurerm_virtual_machine_extension.ama.id }
output "association_id" { value = azurerm_monitor_data_collection_rule_association.this.id }
