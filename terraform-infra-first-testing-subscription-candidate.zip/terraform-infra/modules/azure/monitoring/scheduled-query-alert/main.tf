resource "azurerm_monitor_scheduled_query_rules_alert_v2" "this" {
  name                = var.name
  resource_group_name = var.resource_group_name
  location            = var.location
  scopes              = var.scopes
  description         = var.description
  severity            = var.severity
  enabled             = var.enabled
  evaluation_frequency = var.evaluation_frequency
  window_duration      = var.window_duration
  criteria {
    query                   = var.query
    time_aggregation_method = var.time_aggregation_method
    threshold               = var.threshold
    operator                = var.operator
    metric_measure_column   = var.metric_measure_column
    failing_periods {
      minimum_failing_periods_to_trigger_alert = var.minimum_failing_periods
      number_of_evaluation_periods             = var.evaluation_periods
    }
  }
  dynamic "action" {
    for_each = length(var.action_group_ids) > 0 ? [1] : []
    content { action_groups = var.action_group_ids }
  }
  tags = var.tags
}
