variable "name" { type = string }
variable "resource_group_name" { type = string }
variable "location" { type = string }
variable "scopes" { type = list(string) }
variable "description" { type = string; default = "Managed by Terraform" }
variable "severity" { type = number; validation { condition = contains([0,1,2,3,4],var.severity); error_message = "Severity must be 0-4." } }
variable "enabled" { type = bool; default = true }
variable "evaluation_frequency" { type = string; default = "PT5M" }
variable "window_duration" { type = string; default = "PT15M" }
variable "query" { type = string }
variable "time_aggregation_method" { type = string; default = "Count" }
variable "threshold" { type = number }
variable "operator" { type = string; default = "GreaterThan" }
variable "metric_measure_column" { type = string; default = null }
variable "minimum_failing_periods" { type = number; default = 1 }
variable "evaluation_periods" { type = number; default = 1 }
variable "action_group_ids" { type = list(string); default = [] }
variable "tags" { type = map(string); default = {} }
