# Scheduled query alert
KQL alert v2 with common action group integration. Validate KQL against the workspace schema and Azure Monitor API before deployment.
