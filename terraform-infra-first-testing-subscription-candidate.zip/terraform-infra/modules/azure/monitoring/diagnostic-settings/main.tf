resource "azurerm_monitor_diagnostic_setting" "this" {
  name                       = var.name
  target_resource_id         = var.target_resource_id
  log_analytics_workspace_id = var.workspace_id
  log_analytics_destination_type = var.destination_type
  dynamic "enabled_log" {
    for_each = var.log_categories
    content { category = enabled_log.value }
  }
  dynamic "enabled_log" {
    for_each = var.log_category_groups
    content { category_group = enabled_log.value }
  }
  dynamic "enabled_metric" {
    for_each = var.metric_categories
    content { category = enabled_metric.value }
  }
  lifecycle {
    precondition {
      condition     = length(var.log_categories) + length(var.log_category_groups) + length(var.metric_categories) > 0
      error_message = "Enable at least one supported log, log category group, or metric category."
    }
    precondition {
      condition     = length(var.log_categories) == 0 || length(var.log_category_groups) == 0
      error_message = "Choose explicit log categories OR category groups, not both."
    }
  }
}
