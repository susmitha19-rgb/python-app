# Diagnostic settings
Supply categories actually supported by the target resource. Category groups are not supported by all resources. This module deliberately does not guess supported categories.
