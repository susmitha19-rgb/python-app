variable "name" { type = string }
variable "resource_group_name" { type = string }
variable "short_name" { type = string }
variable "email_receivers" {
  type = map(string)
  description = "Map of receiver names to email addresses; use non-secret addresses."
  default = {}
}
variable "tags" { type = map(string); default = {} }
