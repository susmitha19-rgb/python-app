# Application Insights
Workspace-based Application Insights. Pass the Log Analytics workspace resource ID. Authentication is Entra-only. Public ingestion/query defaults must be reviewed for private networking requirements.
