resource "azurerm_application_insights" "this" {
  name                          = var.name
  location                      = var.location
  resource_group_name           = var.resource_group_name
  application_type              = var.application_type
  workspace_id                  = var.workspace_id
  local_authentication_disabled = true
  internet_ingestion_enabled    = var.internet_ingestion_enabled
  internet_query_enabled        = var.internet_query_enabled
  tags                          = var.tags
}
