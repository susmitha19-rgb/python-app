variable "name" { type = string description = "IAM policy name for Textract API access." }
variable "tags" { type = map(string) default = {} }
