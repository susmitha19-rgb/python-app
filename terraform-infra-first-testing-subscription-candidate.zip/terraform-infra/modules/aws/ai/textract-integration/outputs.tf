output "policy_arn" { value = aws_iam_policy.this.arn description = "Attach to the application execution role." }
