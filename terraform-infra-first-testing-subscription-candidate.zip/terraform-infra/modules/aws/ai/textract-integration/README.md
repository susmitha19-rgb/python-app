# Amazon Textract integration

Textract is an API service, not a standalone resource to provision. This module creates an IAM policy for Textract API calls; attach it to a least-privilege execution role. Review wildcard resource scope against supported Textract IAM resource types and restrict access where possible.
