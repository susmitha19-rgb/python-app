data "aws_iam_policy_document" "textract" {
  statement {
    sid       = "TextractAnalyze"
    effect    = "Allow"
    actions   = ["textract:AnalyzeDocument", "textract:DetectDocumentText", "textract:StartDocumentAnalysis", "textract:GetDocumentAnalysis", "textract:StartDocumentTextDetection", "textract:GetDocumentTextDetection"]
    resources = ["*"]
  }
}
resource "aws_iam_policy" "this" {
  name        = var.name
  description = "Application permissions for Amazon Textract APIs"
  policy      = data.aws_iam_policy_document.textract.json
  tags        = var.tags
}
