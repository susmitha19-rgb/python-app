# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_bedrock_guardrail" "this" {
  name = var.name
  description = var.description
  blocked_input_messaging = var.blocked_input_messaging
  blocked_outputs_messaging = var.blocked_outputs_messaging
  content_policy_config { filters_config { type = "HATE"
   input_strength = "HIGH"
   output_strength = "HIGH" } }
}
