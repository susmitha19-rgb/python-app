output "id" { value = aws_bedrock_guardrail.this.id }
output "arn" { value = aws_bedrock_guardrail.this.arn }
