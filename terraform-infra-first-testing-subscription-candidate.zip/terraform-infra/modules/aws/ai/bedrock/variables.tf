variable "name" {
  description = "Input name for aws_bedrock_guardrail."
  type = string
}

variable "description" {
  description = "Input description for aws_bedrock_guardrail."
  type = string
}

variable "blocked_input_messaging" {
  description = "Input blocked_input_messaging for aws_bedrock_guardrail."
  type = string
}

variable "blocked_outputs_messaging" {
  description = "Input blocked_outputs_messaging for aws_bedrock_guardrail."
  type = string
}
