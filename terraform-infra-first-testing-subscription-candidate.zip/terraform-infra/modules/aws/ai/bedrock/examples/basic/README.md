Example pending module implementation. Do not deploy.
