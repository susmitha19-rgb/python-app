variable "name" {
  description = "Input name for aws_iam_role."
  type = string
}

variable "assume_role_policy" {
  description = "Input assume_role_policy for aws_iam_role."
  type = string
}
