# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_cognito_user_pool" "this" {
  name = var.name
  tags = var.tags
}
