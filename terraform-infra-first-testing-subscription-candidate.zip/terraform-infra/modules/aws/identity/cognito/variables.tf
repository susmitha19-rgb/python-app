variable "name" {
  description = "Input name for aws_cognito_user_pool."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
