# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_dynamodb_table" "this" {
  name = var.name
  hash_key = var.hash_key
  tags = var.tags
  billing_mode = "PAY_PER_REQUEST"
   attribute { name = var.hash_key
   type = var.hash_key_type }
   point_in_time_recovery { enabled = true }
}
