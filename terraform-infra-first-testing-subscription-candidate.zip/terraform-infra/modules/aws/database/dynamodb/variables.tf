variable "name" {
  description = "Input name for aws_dynamodb_table."
  type = string
}

variable "hash_key" {
  description = "Input hash_key for aws_dynamodb_table."
  type = string
}

variable "hash_key_type" {
  description = "Input hash_key_type for aws_dynamodb_table."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
