variable "cluster_identifier" {
  description = "Input cluster_identifier for aws_rds_cluster."
  type = string
}

variable "engine" {
  description = "Input engine for aws_rds_cluster."
  type = string
}

variable "master_username" {
  description = "Input master_username for aws_rds_cluster."
  type = string
}

variable "master_password" {
  description = "Input master_password for aws_rds_cluster."
  type = string
  sensitive = true
}

variable "storage_encrypted" {
  description = "Input storage_encrypted for aws_rds_cluster."
  type = bool
  default = true
}

variable "skip_final_snapshot" {
  description = "Input skip_final_snapshot for aws_rds_cluster."
  type = bool
  default = false
}

variable "tags" {
  type = map(string)
  default = {}
}
