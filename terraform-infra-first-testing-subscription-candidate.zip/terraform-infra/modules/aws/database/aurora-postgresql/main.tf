# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_rds_cluster" "this" {
  cluster_identifier = var.cluster_identifier
  engine = var.engine
  master_username = var.master_username
  master_password = var.master_password
  storage_encrypted = var.storage_encrypted
  skip_final_snapshot = var.skip_final_snapshot
  tags = var.tags
  # Cluster instances must be provisioned separately by the consuming composition.
}
