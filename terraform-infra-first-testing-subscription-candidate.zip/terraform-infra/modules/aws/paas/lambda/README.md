# lambda

Resource-level module for `aws_lambda_function`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
