# secrets-manager

Resource-level module for `aws_secretsmanager_secret`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
