resource "aws_secretsmanager_secret" "this" {
  name = var.name
  kms_key_id = var.kms_key_id
  recovery_window_in_days = 30
  tags = var.tags
}
