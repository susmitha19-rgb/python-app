# ecr

Creates `aws_ecr_repository`. All required values are passed by the calling root. No real subscriptions, accounts, secrets, or regions are embedded.

**Review before deployment:** Check provider schema, regional availability, SKU, security controls, and dependency resources. This module has not been cloud-tested.
