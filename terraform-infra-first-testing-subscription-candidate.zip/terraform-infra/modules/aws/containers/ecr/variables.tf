variable "name" {
  description = "Input name for aws_ecr_repository."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
