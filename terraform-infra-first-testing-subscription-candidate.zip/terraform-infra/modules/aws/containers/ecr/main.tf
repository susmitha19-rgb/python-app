# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_ecr_repository" "this" {
  name = var.name
  tags = var.tags
  image_scanning_configuration { scan_on_push = true }
   encryption_configuration { encryption_type = "AES256" }
}
