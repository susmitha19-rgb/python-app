# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_cloudwatch_event_bus" "this" {
  name = var.name
  tags = var.tags
}
