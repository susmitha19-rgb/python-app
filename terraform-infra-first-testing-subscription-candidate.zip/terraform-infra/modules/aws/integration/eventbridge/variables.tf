variable "name" {
  description = "Input name for aws_cloudwatch_event_bus."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
