variable "name" {
  description = "Input name for aws_sqs_queue."
  type = string
}

variable "message_retention_seconds" {
  description = "Input message_retention_seconds for aws_sqs_queue."
  type = number
  default = 345600
}

variable "tags" {
  type = map(string)
  default = {}
}
