variable "cidr_block" {
  description = "Input cidr_block for aws_vpc."
  type = string
}

variable "enable_dns_support" {
  description = "Input enable_dns_support for aws_vpc."
  type = bool
  default = true
}

variable "enable_dns_hostnames" {
  description = "Input enable_dns_hostnames for aws_vpc."
  type = bool
  default = true
}

variable "tags" {
  type = map(string)
  default = {}
}
