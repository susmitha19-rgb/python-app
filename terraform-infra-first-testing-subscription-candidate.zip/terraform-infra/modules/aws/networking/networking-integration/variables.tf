variable "vpc_id" {
  description = "Input vpc_id for aws_subnet."
  type = string
}

variable "cidr_block" {
  description = "Input cidr_block for aws_subnet."
  type = string
}

variable "availability_zone" {
  description = "Input availability_zone for aws_subnet."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
