# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_subnet" "this" {
  vpc_id = var.vpc_id
  cidr_block = var.cidr_block
  availability_zone = var.availability_zone
  tags = var.tags
}
