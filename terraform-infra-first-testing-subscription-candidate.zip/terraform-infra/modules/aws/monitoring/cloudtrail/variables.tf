variable "name" {
  description = "Input name for aws_cloudtrail."
  type = string
}

variable "s3_bucket_name" {
  description = "Input s3_bucket_name for aws_cloudtrail."
  type = string
}

variable "include_global_service_events" {
  description = "Input include_global_service_events for aws_cloudtrail."
  type = bool
  default = true
}

variable "is_multi_region_trail" {
  description = "Input is_multi_region_trail for aws_cloudtrail."
  type = bool
  default = true
}

variable "enable_log_file_validation" {
  description = "Input enable_log_file_validation for aws_cloudtrail."
  type = bool
  default = true
}

variable "tags" {
  type = map(string)
  default = {}
}
