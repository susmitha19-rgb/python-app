output "id" { value = aws_cloudtrail.this.id }
output "arn" { value = aws_cloudtrail.this.arn }
