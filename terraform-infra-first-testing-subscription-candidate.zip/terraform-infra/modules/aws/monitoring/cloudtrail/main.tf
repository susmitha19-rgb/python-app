# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_cloudtrail" "this" {
  name = var.name
  s3_bucket_name = var.s3_bucket_name
  include_global_service_events = var.include_global_service_events
  is_multi_region_trail = var.is_multi_region_trail
  enable_log_file_validation = var.enable_log_file_validation
  tags = var.tags
}
