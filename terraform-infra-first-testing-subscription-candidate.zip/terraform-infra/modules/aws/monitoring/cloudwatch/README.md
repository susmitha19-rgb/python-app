# cloudwatch

Resource-level module for `aws_cloudwatch_log_group`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
