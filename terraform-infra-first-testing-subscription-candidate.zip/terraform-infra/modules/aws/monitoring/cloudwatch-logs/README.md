# cloudwatch-logs

Resource implementation mirrored from `modules/aws/monitoring/cloudwatch` to maintain compatibility with the existing repository taxonomy. Prefer a single canonical module in new integrations. Provider schema and deployment validation remain required.
