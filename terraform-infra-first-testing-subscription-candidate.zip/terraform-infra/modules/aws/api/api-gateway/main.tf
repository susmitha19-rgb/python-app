# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_apigatewayv2_api" "this" {
  name = var.name
  protocol_type = var.protocol_type
  tags = var.tags
}
