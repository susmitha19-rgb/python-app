variable "name" {
  description = "Input name for aws_apigatewayv2_api."
  type = string
}

variable "protocol_type" {
  description = "Input protocol_type for aws_apigatewayv2_api."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
