# s3

Resource-level module for `aws_s3_bucket`. No provider configuration or credentials inside module.

**Status:** Implemented candidate; provider validation and live tests required.
