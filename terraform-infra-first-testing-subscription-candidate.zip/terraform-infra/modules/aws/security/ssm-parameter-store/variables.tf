variable "name" {
  description = "Input name for aws_ssm_parameter."
  type = string
}

variable "type" {
  description = "Input type for aws_ssm_parameter."
  type = string
}

variable "value" {
  description = "Input value for aws_ssm_parameter."
  type = string
  sensitive = true
}

variable "tags" {
  type = map(string)
  default = {}
}
