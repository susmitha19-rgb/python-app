# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_ssm_parameter" "this" {
  name = var.name
  type = var.type
  value = var.value
  tags = var.tags
}
