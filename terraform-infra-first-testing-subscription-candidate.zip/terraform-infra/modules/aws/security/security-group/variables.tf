variable "name" {
  description = "Input name for aws_security_group."
  type = string
}

variable "description" {
  description = "Input description for aws_security_group."
  type = string
}

variable "vpc_id" {
  description = "Input vpc_id for aws_security_group."
  type = string
}

variable "tags" {
  type = map(string)
  default = {}
}
