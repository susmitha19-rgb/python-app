# Reusable module. Supply real values through root configuration; do not commit credentials.
resource "aws_security_group" "this" {
  name = var.name
  description = var.description
  vpc_id = var.vpc_id
  tags = var.tags
  revoke_rules_on_delete = true
}
