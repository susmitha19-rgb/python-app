variable "description" {
  description = "Input description for aws_kms_key."
  type = string
}

variable "enable_key_rotation" {
  description = "Input enable_key_rotation for aws_kms_key."
  type = bool
  default = true
}

variable "tags" {
  type = map(string)
  default = {}
}
