# lambda

Resource implementation mirrored from `modules/aws/paas/lambda` to maintain compatibility with the existing repository taxonomy. Prefer a single canonical module in new integrations. Provider schema and deployment validation remain required.
