variable "name" {
  type = string
}
variable "role_arn" {
  type = string
}
variable "runtime" {
  type = string
  default = "python3.12"
}
variable "handler" {
  type = string
  default = "handler.lambda_handler"
}
variable "filename" {
  type = string
}
variable "timeout" {
  type = number
  default = 30
}
variable "tags" {
  type = map(string)
  default = {}
}
