resource "aws_lambda_function" "this" {
  function_name = var.name
  role = var.role_arn
  runtime = var.runtime
  handler = var.handler
  filename = var.filename
  source_code_hash = filebase64sha256(var.filename)
  timeout = var.timeout
  tags = var.tags
}
