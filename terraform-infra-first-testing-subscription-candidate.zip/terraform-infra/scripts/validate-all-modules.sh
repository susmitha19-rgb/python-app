#!/usr/bin/env bash
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
command -v terraform >/dev/null 2>&1 || { echo "ERROR: terraform CLI is required" >&2; exit 2; }
terraform -chdir="$ROOT" fmt -check -recursive || exit 1
failures=0
while IFS= read -r -d '' dir; do
  printf '\n== %s ==\n' "${dir#"$ROOT"/}"
  if ! terraform -chdir="$dir" init -backend=false -input=false -no-color; then
    echo "INIT FAILED: $dir"; failures=$((failures+1)); continue
  fi
  if ! terraform -chdir="$dir" validate -no-color; then
    echo "VALIDATE FAILED: $dir"; failures=$((failures+1))
  fi
done < <(find "$ROOT/modules" "$ROOT/cloud-infra" "$ROOT/environments" -name '*.tf' -printf '%h\0' | sort -zu)
echo "Validation failures: $failures"
(( failures == 0 ))
