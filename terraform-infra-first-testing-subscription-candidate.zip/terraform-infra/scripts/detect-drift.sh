#!/usr/bin/env bash
set -euo pipefail
echo "NOT IMPLEMENTED: script requires enterprise-specific design" >&2
exit 2
