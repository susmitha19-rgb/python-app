# Root composition for uat/aws. Add approved parent modules here.
