# UAT AZURE root

Not deployable until remote backend, identities, and approved module compositions are configured. Never commit real secrets or terraform.tfstate.
