# Root composition for dev/aws. Add approved parent modules here.
