variable "location" { type = string; default = "eastus" }
variable "resource_group_name" { type = string; default = "rg-monitoring-example" }
variable "monitoring_enabled" { type = bool; default = false }
variable "action_group_email" { type = string; default = "xxx@domain.com" }
variable "tags" { type = map(string); default = {} }
