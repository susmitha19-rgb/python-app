# Root composition for prod/aws. Add approved parent modules here.
