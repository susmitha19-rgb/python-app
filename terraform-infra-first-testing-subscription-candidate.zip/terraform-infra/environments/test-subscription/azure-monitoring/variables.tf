variable "subscription_id" { type = string; description = "Testing subscription ID" }
variable "resource_group_name" { type = string; description = "Existing test resource group name" }
variable "location" { type = string; description = "Azure deployment region" }
variable "workspace_name" { type = string; description = "Globally appropriate Log Analytics workspace name" }
variable "action_group_name" { type = string; description = "Azure Monitor action group name" }
variable "action_group_short_name" { type = string; description = "Short name (12 characters maximum)" }
variable "notification_email" { type = string; description = "Test alert notification email" }
variable "tags" { type = map(string); default = { environment = "test", managed_by = "terraform" } }
