# First Azure test-subscription deployment

**Not a production certification.** This root provisions the Azure monitoring baseline's Log Analytics workspace and common action group, assuming an existing resource group.

1. Set up Azure CLI / workload identity authentication and select the dedicated test subscription.
2. Copy `terraform.tfvars.example` to `terraform.tfvars`, replace all example values.
3. Configure an approved remote backend before shared/team use. Do not commit state, secrets, or `terraform.tfvars`.
4. Run `terraform init`, `terraform fmt -check`, `terraform validate`, `terraform plan -out=tfplan`, review the plan, then `terraform apply tfplan` only after approval.
5. Verify resources in Azure, inspect Azure Monitor configuration, and use `terraform destroy` only for intentionally disposable test resources.

The monitoring parent module may contain optional features that require separate provider/schema testing. Do not enable those features until verified.
