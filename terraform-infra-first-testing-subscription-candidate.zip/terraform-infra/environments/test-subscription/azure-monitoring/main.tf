# First test deployment deliberately limits scope to a Log Analytics Workspace
# and common Action Group. Additional monitoring inventory must be enabled after validation.
module "monitoring" {
  source                  = "../../../cloud-infra/monitoring/azure-monitoring-baseline"
  workspace_name          = var.workspace_name
  resource_group_name     = var.resource_group_name
  location                = var.location
  action_group_name       = var.action_group_name
  action_group_short_name = var.action_group_short_name
  email_receivers         = { operations = var.notification_email }
  tags                    = var.tags
}
