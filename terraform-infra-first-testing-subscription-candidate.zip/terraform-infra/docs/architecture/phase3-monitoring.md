# Phase 3: Azure Monitoring extensions

## Implemented
- Windows performance DCR with Log Analytics destination
- Azure Monitor Agent VM extension and DCR association (Windows/Linux; requires compatible DCR)
- Subscription-scoped activity log alerts
- Azure Monitor workspace for Managed Prometheus storage
- Opt-in parent module wiring (all features default to off)

## Not implemented / do not assume complete
- AKS metrics addon configuration, recording rules, Prometheus alert rules, Grafana
- Full VM Insights dependency-map collection or Linux DCR
- Automatic subscription-wide discovery: inventory is explicit; use Azure Resource Graph/external inventory process for hybrid discovery
- Full 17-service metric baseline: metrics/thresholds vary by SKU and region; validate in target subscription
- AWS service resource modules and remaining Azure service modules

## Enterprise implementation requirements
- Scope subscription activity alerts with `/subscriptions/<subscription-id>`.
- Keep metric severities 0–4; severity 4 must not notify the action group by default.
- The common action group is created once by the parent module.
- Validate metrics against `Microsoft.Insights/metricDefinitions` and diagnostic categories against each resource before enabling.
- Run `terraform fmt -check -recursive`, `terraform init -backend=false`, `terraform validate`, security scans and sandbox plans.
- Pin the actual provider version in environment lockfiles; `~> 4.0` is a compatibility range, not a tested pin.
- Never commit credentials or real `terraform.tfvars` secrets.
