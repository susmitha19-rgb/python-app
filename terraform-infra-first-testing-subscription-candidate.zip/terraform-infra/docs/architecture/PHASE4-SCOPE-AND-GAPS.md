# Phase 4 scope and production readiness

This is **not** a fully implemented or production-certified Azure/AWS estate.

## New implementation candidates
Azure: storage account, Key Vault, App Service Plan, Container Registry. AWS: S3 (public-access block, encryption and versioning), Lambda, Secrets Manager, CloudWatch log group. Azure Monitoring: explicit VM CPU Sev 1 alert catalogue.

## Not yet implemented
Full VM Insights, Linux DCR, AKS Prometheus addon/recording rules, hybrid Azure Resource Graph discovery, service-wide Sev 0–4 alerts, all remaining Azure and AWS services, deployable environment composition, and live integration tests.

## Security caveats
Azure Storage/Key Vault/ACR default to public network access disabled: private endpoints and DNS must be configured separately. S3 uses SSE-S3 rather than customer-managed KMS. CloudWatch KMS encryption is optional. AWS Lambda requires a real artifact and IAM role. No secrets should be stored in tfvars or committed to Git.

## Release gate
Run `terraform fmt -check -recursive`, `terraform init -backend=false`, `terraform validate` for each module and root; run TFLint/Checkov; review `terraform plan` in non-production; test dependencies and alert delivery; require change approval before production apply. Terraform CLI and cloud credentials were not available during archive creation.
