# Repository model

Based on the supplied IaC reference architecture. `environments` are deployable roots only after configuration, `cloud-infra` are parent composition modules, `modules` contain resource-level modules, `shared` holds conventions, `policies` and `tests` hold controls, `infra-pipelines` holds CI/CD definitions.

Use path-scoped CI and CODEOWNERS. Avoid a single shared Terraform state across Azure/AWS or dev/uat/prod. Production deployment requires approval and backend configuration.
