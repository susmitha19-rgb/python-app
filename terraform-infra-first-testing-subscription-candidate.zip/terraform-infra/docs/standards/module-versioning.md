Monorepo modules need path-aware releases or a registry; Git source subdirectories share repository tags. Never assume a per-folder Git tag can be independently resolved.
