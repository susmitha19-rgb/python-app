Resource naming must be defined per service (Azure service-specific constraints; AWS service-specific constraints). Do not force a single pattern on all resource types.
