Private networking where supported, managed identity or IAM roles, encrypted storage, TLS, logging, least privilege and approved regions. Review service-specific exemptions.
