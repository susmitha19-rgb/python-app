# Enterprise module contract

1. One cohesive resource concern per child module; parent modules compose child modules.
2. Use `main.tf`, `variables.tf`, `outputs.tf`, `versions.tf`, README; `locals.tf` and `data.tf` only when complexity justifies them.
3. Root modules configure providers and backends; child modules declare provider requirements but do not configure providers.
4. Prefer explicit typed inputs, validations, stable outputs, resource IDs, tags, safe defaults and least privilege.
5. Avoid hardcoded tenant/subscription/account IDs, secrets, and credentials. Avoid outputs containing sensitive values.
6. `terraform fmt -check -recursive`, `terraform validate`, lint, security scanning and unit/integration tests before approval.
7. State isolation per environment and cloud; remote encrypted state, locking, workload identity federation, restricted access.
8. Treat provider major-version changes as breaking changes; lock providers in roots and review upgrades.
9. Module ownership and code review are required. Release independently using path-aware versioning or registry releases.
10. Scaffolds are not deployable and must never be represented as tested implementations.
