Recommended tags: environment, application, owner, cost_center, managed_by, data_classification. Verify which resources support tags.
