Module developers own implementations; platform reviewers own interfaces and security; repository maintainers own integration and release.
