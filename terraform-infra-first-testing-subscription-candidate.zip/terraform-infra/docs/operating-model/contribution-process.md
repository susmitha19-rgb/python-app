Feature branch -> module tests -> security scan -> reviewer approvals -> integration tests -> merge -> release.
