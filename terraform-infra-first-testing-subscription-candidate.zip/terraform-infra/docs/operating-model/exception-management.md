Document owner, reason, risk, compensating control, approval and expiry for exceptions.
