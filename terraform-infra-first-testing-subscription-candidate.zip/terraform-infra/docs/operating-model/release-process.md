Pin module refs to immutable Git commits or reviewed tags; maintain changelog and compatibility notes.
