CI templates are illustrative; configure pipeline platform, workload identity, remote backend and security scanners before using.
