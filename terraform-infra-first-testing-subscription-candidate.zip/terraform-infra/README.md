# terraform-infra — enterprise multicloud IaC starter

**This is a repository architecture and module starter, NOT a fully implemented or production-validated infrastructure stack.**

The folder layout follows the supplied reference architecture: `environments/{dev,uat,prod}/{azure,aws}`, `cloud-infra`, `modules`, `shared`, `policies`, `tests`, `infra-pipelines`, `scripts`, `templates`, and `docs`.

## Delivered

- Resource-level module directories for all requested Azure and AWS services, plus monitoring baseline service extensions.
- Three **implemented** Azure Monitoring child modules: Log Analytics workspace, common email action group, generic metric alert. These require provider validation and live testing.
- Azure Monitoring architecture/severity baseline, parent-module composition scaffolds, environment roots, standards, CI formatting example.
- All other service modules are explicitly **scaffolds**, not implementations.

## Before deployment

1. Confirm AzureRM and AWS provider versions, SKU choices and region availability.
2. Configure remote backends and identity federation for each environment.
3. Implement required child modules and parent compositions.
4. Set resource IDs and verify metric namespaces and alert thresholds.
5. Run `terraform fmt -check -recursive`, `terraform init -backend=false`, `terraform validate`, lint/security checks, tests and authenticated integration plans.
6. Never commit `.tfstate`, credentials, secrets, or real `terraform.tfvars`.

## Important ambiguities

- `Redis 2` could mean two instances, Redis Enterprise, or another Redis offering; both Redis Cache and Redis Enterprise module directories are included as design options.
- Microsoft Foundry and Azure ML Foundry are treated as separate design scopes until service boundaries are confirmed.
- Video Indexer may require ARM/API-specific deployment and provider support verification.
- AWS networking integration and Textract integration are composition concerns and require architecture details.

See `IMPLEMENTATION-MATRIX.csv` for implementation status and `docs/standards/module-development.md` for standards.


## Final delivery caveat
See IMPLEMENTATION-STATUS-FINAL.csv. `RESOURCE_CODE_PRESENT_UNVERIFIED` means Terraform resource blocks exist, **not** that the module is validated or deployment-ready. Modules marked NOT_IMPLEMENTED require engineering before use.
