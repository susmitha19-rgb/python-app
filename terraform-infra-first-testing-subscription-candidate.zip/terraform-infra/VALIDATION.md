# Validation status

- Generated repository files and archive structure: checked by generation script.
- Terraform CLI: not available in this execution environment; `terraform fmt`, `init`, and `validate` NOT RUN.
- Azure/AWS authentication: not available; plan/apply and integration tests NOT RUN.
- Only three monitoring modules have substantive Terraform resources. All others are clearly labeled scaffolds.
- Terraform/provider syntax and Azure service support must be checked against pinned versions before production use.
